#include <arpa/inet.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

#define SIZE 1024       /* The SIZE is used for holding the buffer size.*/
#define ARGUMENT_MAX 3  /* The ARGUMENT_MAX is used for maximum no. of arguments.*/
#define IP 3            /* Verification purpose for IP address.*/

/**
 * The main function
 *
 * The main function helps here to create a socket and try to connect 
 * to the server. Then sends the one KB data reading from the input 
 * file to the server. The received data from the server is stored 
 * in the output file.
 *
 * @param argc holds the number of arguments.
 * @param argv holds the address of the command line arguments.
*/
void main(int argc, char *argv[])
{
	int sockfd;
	int in_fd, out_fd, status, count, i, flag;
	char *data = NULL;
	struct sockaddr_in serv;
	unsigned short portno;

	if (ARGUMENT_MAX != argc) {
		printf("Use syntax :<exec_name> <portno> <inet>\n");
		return;
	}

	/*verifying the port number.*/
        for (i = 0; ('\0' != argv[1][i]); i++) {
                if (!(('0' <= argv[1][i]) && ('9' >= argv[1][i]))) {
                        printf("check the port no and renter\n");
                        printf("follow the syntax :<exec_name> <portno> <inet>\n");
                        return;
                }
        }

        /*verification of IP address.*/
        for (i = 0, count = 0, flag = 0; ('\0' != argv[2][i]); i++) {
                if ('.' == argv[2][i])
                        count++;
                else if (('0' <= argv[2][i]) && ('9' >= argv[2][i]))
                        continue;
                else {
                        flag = 1;
                        break;
                }
        }

        if ((IP != count) || (flag)) {
                printf("check the IP address and reneter\n");
                printf("follow the syntax :<exec_name> <portno> <inet>\n");
                return;
        }

	portno = atoi(argv[1]);

	sockfd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (0 > sockfd) {
		printf("failed to create socket\n");
		return;
	}

	data = (char *)malloc(SIZE * sizeof(char));
	if (NULL == data) {
		printf("failed to allocate the 1KB for data\n");
		return;
	}

	bzero(&serv, sizeof(serv));
	serv.sin_family = AF_INET;
	serv.sin_port = htons(portno);
	serv.sin_addr.s_addr = inet_addr(argv[2]);

	/*sending connection request to the server.*/
	status = connect(sockfd, (struct sockaddr *)&serv, sizeof(serv));
	if (0 > status) {
		printf("failed to establish connection\n");
		return;
	}

	printf("connected with server\n");

	/*opening the input file*/
	in_fd = open("../files/input", O_RDONLY);
	if (0 > in_fd) { 
		printf("no input file to do operations\n");
		return;
	}

	/*opening the output file if present or creating one if not present*/ 
	out_fd = open("../files/output", O_CREAT | O_TRUNC | O_WRONLY, 0664);
	if (0 > out_fd) {
		printf("failed to open the output file\n");
		return;
	}

	status = recv(sockfd, data, SIZE, 0);
	if (0 > status) {
		printf("receive system call failed\n");
		return;
	}

	/*the server side DMA call is verifying here.*/
	if (!strcmp(data, "enomem")) {
		printf("the DMA call is failed in server\n");
		return;
	}

	printf("The data sending to the server\n");

	while (status = read(in_fd, data, SIZE)) {
		if (0 > status) {
			printf("read system call failed\n");
			return;
		}

		data[status] = '\0';

		status = send(sockfd, data, strlen(data), 0);
		if (0 > status) {
			printf("send system call failed\n");
			return;
		}

		status = recv(sockfd, data, SIZE, 0);
		if (0 > status) {
			printf("receive system call failed\n");
			return;
		}

		data[status] = '\0';

		status = write(out_fd, data, strlen(data));
		if (0 > status) {
			printf("write system call failed\n");
			return;	
		}
	}

	status = send(sockfd, "stop", 4, 0);
	if (0 > status) {
		printf("send system call failed\n");
		return;
	}

	printf("the output file is generated\n");
	free(data);
	close(sockfd);
}
