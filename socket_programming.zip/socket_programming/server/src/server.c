#include <arpa/inet.h>
#include <netinet/in.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

#define SIZE 1024       /* The SIZE is used for holding the buffer size.*/
#define ARGUMENT_MAX 3  /* The ARGUMENT_MAX is used for maximum no. of arguments.*/
#define IP 3            /* Verification purpose for IP address.*/

/**
 * Converts the small case alphabets to capital letters
 *
 * This function receives the data from the client and converts the lower to 
 * uppercase alphabets and send back to the client.
 *
 * @param temp holds the address of the socket id.
 *
 * @return NULL : if the function excecuted.
*/

void* request_handler(void *temp)
{
	int *store = (int *)temp;
	int i, status, sockid = *store;
	char *data = NULL;

	data = (char *)malloc(SIZE * sizeof(char));

	/*verifying the DMA call is failure or not.*/
	if (NULL == data) {
		printf("failed to create the buffer\n");

		status = send(sockid, "enomem", strlen("enomem"), 0);
		if (0 > status) 
			printf("send system call failed\n");
	} else {
		status = send(sockid, "ack", strlen("ack"), 0);
		if (0 > status) 
			printf("send system call failed\n");
		else {	
			printf("The received data is modifying\n");
			while (1) {
				status = recv(sockid, data, SIZE, 0);
				if (0 > status) { 
					printf("receive system call failed\n");
					break;
				}

				data[status] = '\0';

				if (!strcmp(data,"stop"))
					break;

				/*foor loop converting small letters to capital letters.*/
				for (i = 0; '\0' != data[i]; i++) {
					if (('a' <= data[i]) && ('z' >= data[i]))
						data[i] = (data[i] - ('a' - 'A'));
				}

				status = send(sockid, data, strlen(data), 0);
				if (0 > status) {
					printf("send system call failed\n");
					break;
				}
			}
			printf("The received data is modified and sent back\n");
		}
	}

	free(data);
	pthread_exit(NULL);
}



/**
 * The main function
 *
 * The main function helps here to create a socket and waiting for the clients 
 * to handle the request. If a client is requested for connection. the function
 * creates a thread and assign the work to the request handler function.
 *
 * @param argc holds the number of arguments.
 * @param argv holds the address of the command line arguments.
*/
void main(int argc, char *argv[])
{
	int sockfd, newsockfd, status, client_size, i, count ,flag;
	struct sockaddr_in serv, client;
	unsigned short portno;
	pthread_t threadno;

	if (ARGUMENT_MAX != argc) {
		printf("the syntax :<exec_name> <portno> <inet>\n");
		return;
	}

	/*verifying the port number.*/
	for (i = 0; ('\0' != argv[1][i]); i++) {
		if (!(('0' <= argv[1][i]) && ('9' >= argv[1][i]))) {
			printf("check the port no and renter\n");
			printf("follow the syntax :<exec_name> <portno> <inet>\n");
			return;
		}
	}

	/*verification of IP address.*/
	for (i = 0, count = 0, flag = 0; ('\0' != argv[2][i]); i++) {
		if ('.' == argv[2][i])
			count++;
		else if (('0' <= argv[2][i]) && ('9' >= argv[2][i]))
			continue;
		else {
			flag = 1;
			break;
		}
	}

	if ((IP != count) || (flag)) {
		printf("check the IP address and reneter\n");
		printf("follow the syntax :<exec_name> <portno> <inet>\n");
		return;
	}

	portno = atoi(argv[1]);

	sockfd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (0 > sockfd) {
		printf("failed to create socket\n");
		return;
	}

	bzero(&serv, sizeof(serv));
	serv.sin_family = AF_INET;
	serv.sin_port = htons(portno);
	serv.sin_addr.s_addr = inet_addr(argv[2]);

	status = bind(sockfd, (struct sockaddr*)&serv, sizeof(serv));
	if (0 > status) {
		printf("failed to bind : reverify the IP address and portno\n");
		return;
	}

	status = listen(sockfd, 10);
	if (0 > status) {
		printf("listen call is failed\n");
		return;
	}

	client_size = sizeof(client);

	while (1) {        
		printf("waiting for connection...\n");

		/*Accepting the connection request from the clients*/
		newsockfd = accept(sockfd, (struct sockaddr *)&client, &client_size);
		if(0 > newsockfd)
			printf("failed to accept the connection \n");

		printf("client connected\n");

		/*Creating the threads for request handler function.*/
		status = pthread_create(&threadno, NULL, request_handler, &newsockfd);
		if (0 > status)
			printf("failed to create the thread\n");
	}

	close(sockfd);
	return;
}
